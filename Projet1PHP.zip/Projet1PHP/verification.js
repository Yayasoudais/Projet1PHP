let rep = confirm('Voulez-vous supprimer ?');

if (rep) {
    var xml = new XMLHttpRequest();

    xml.onreadystatechange = function () {
        if (xml.status == 200) {
            console.log(xml.responseText);
        }
    }
    
    xml.open('GET', 'suppression.php', true);
    xml.send();
  
}

